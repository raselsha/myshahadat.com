-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: May 27, 2016 at 02:41 AM
-- Server version: 5.5.45-37.4-log
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `shahahbr_contact`
--

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE IF NOT EXISTS `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `mobile`, `description`, `user_id`) VALUES
(1, 'Shahadat Hossain', '01737266685', 'This is my own mobile number', 4),
(2, 'Abdur Rashid', '01737266685', '', 4),
(3, 'Abdul Ahad', '01911064427', '', 4),
(4, 'Abdul Kuddus', '01681619901', '', 4),
(5, 'Abul Kasim', '01711977819', '', 4),
(6, 'Ahmad Ali ', '01777759553', '', 4),
(7, 'Al-Amin', '01912397569', '', 4),
(10, 'Anisur Rahman ', '01720045251', '', 4),
(11, 'Anando', '0161426698', '', 4),
(12, 'Anando', '01833315612', '', 4),
(13, 'apu', '01715150316', '', 4),
(14, 'arif ', '01751020060', '', 4),
(18, 'Ahsan', '01742618969', '', 4);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `mobile` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `auth_code` varchar(32) DEFAULT NULL,
  `photo` varchar(100) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `mobile`, `email`, `password`, `auth_code`, `photo`, `status`) VALUES
(4, 'Shahadat Hossain', '01737266685', 'raselsha@gmail.com', '202cb962ac59075b964b07152d234b70', '9c18478dd8414be0e9106b135f58c9e8', '93071042001.jpg', 1),
(18, 'Shahadat Hossain', '01737266685', 'shahadat@runnercyberlink.com', '202cb962ac59075b964b07152d234b70', '0b7c65491ff4d08ebf296fcc1d27d108', NULL, 1),
(19, 'Shahadat Hossain', '01737266685', 'bucse36eve@gmail.com', NULL, 'ed8ff7778cb972f6c57e1c2f76c71c66', NULL, 0),
(20, 'samawat', '1', 'samawat@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '6acba60a58ee189e1c42a3bee9767f39', NULL, 1);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `contacts`
--
ALTER TABLE `contacts`
  ADD CONSTRAINT `contacts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
