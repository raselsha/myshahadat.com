1. Unzip the file my_contacts.zip in www directory of any webserver. if need to copy all files in the root, do it.

2. Create a database in a webserver

3. Import my_contacts.sql into mysql database server

4. Open application\config\database.php

5. Set your database host,user,password and database name

6. Open application\config\config.php

7. Set base url of the project

8. Now go to web browser and open the project 